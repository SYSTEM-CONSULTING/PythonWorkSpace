Example project.
